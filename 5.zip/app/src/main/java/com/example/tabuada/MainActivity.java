package com.example.tabuada;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    EditText text_Set;
    Button   button;
    ListView text_Result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
        @SuppressLint("WrongViewCast")
        public void Calcular(View view){
            text_Set=findViewById(R.id.textNum);
            button=findViewById(R.id.button);
            text_Result=findViewById(R.id.textResult);
            int valor= Integer.parseInt(text_Set.getText().toString());
            int j2=valor;
            for(int i=0;i<10;i++){
                text_Result.setText(valor+"+"+i+"="+j2);
                j2=j2+valor;
                 }
            }


    }

}