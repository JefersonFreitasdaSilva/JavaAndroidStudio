package com.example.ordem;
import java.io.FileOutputStream;
import java.util.Collections;
import java.io.FileOutputStream;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText et;
    Button bt;
    ListView lv;
    ArrayList<Integer> lista;
    ArrayAdapter<Integer> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et=findViewById(R.id.et_novoNumero);
        bt=findViewById(R.id.bt_adicionar);
        lv=findViewById(R.id.lv);

        lista = new ArrayList<>();
        adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);

        lv.setAdapter(adapter);

        bt.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int numero=Integer.parseInt(et.getText().toString());
                lista.add(numero);
                Collections.sort(lista);
                adapter.notifyDataSetChanged();
                et.setText("");
            }
        });


    }
    public void Gravacao(View view) {
        try {
            // abre o arquivo para gravação
            FileOutputStream arquivoGravar = openFileOutput("lista_numeros.txt", MODE_APPEND);

            // percorre a lista de números e grava cada um no arquivo
            for (int i = 0; i < lista.size(); i++) {
                String numeroStr = lista.get(i).toString() + "\n";
                arquivoGravar.write(numeroStr.getBytes());
            }

            // fecha o arquivo
            arquivoGravar.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
