1. Crie uma aplicação que permita a digitação de números e mostre esses
números em tela de forma ordenada. Ou seja, desenvolver uma lógica que
deverá permitir a inclusão de n números em qualquer sequência e em seguida
exibi-los em ordem crescente.
2. Disponibilize uma opção de gravar os números visualizados em um
arquivo txt.